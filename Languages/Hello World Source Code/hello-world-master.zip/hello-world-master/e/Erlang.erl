-module(erlang_hw).
-export([start/0]).

start() ->
  io:format("Hello World~n").